# Rembox Study Guide Plugin

Create detailed study materials from your current sources using an independent, subject-neutral layout.

Select the plugin in a new Codex task, attach your materials, and request a study guide, exam review, cram sheet, flashcards, or practice questions. Specify PDF or DOCX when you want a file. Otherwise, output stays in chat.

The plugin contains one coordinated skill, a complete typography/color/layout specification, and quality checks. It requires no sample guide or course attachment to define its design. It uses only current supplied materials for factual content unless you explicitly request supplemental explanations.

Editable instructions: skills/rembox-study-guide/SKILL.md
Layout: skills/rembox-study-guide/references/layout.md
Quality checks: skills/rembox-study-guide/references/quality-checks.md

File rendering uses the available Codex document/PDF tools and runtime. No external service connection or API key is required by this plugin.

## MCP app

This plugin also includes a no-auth MCP server and inline RemStudy widget for ChatGPT developer mode. It exposes:

- `show_remstudy_widget` to display the supplied RemStudy artwork in chat.
- `get_rembox_study_guide_spec` to load the complete authoring, source-boundary, layout, and quality rules for a requested deliverable.
- `audit_rembox_markdown` to check the required heading and hierarchical-bullet structure before delivery.

The specification tool displays an inline RemStudy widget using `assets/remstudy-widget.png`. The same supplied image is the plugin's local logo and composer icon.

Run it locally with `npm install` followed by `npm start`. The Streamable HTTP endpoint is `http://127.0.0.1:8787/mcp`. ChatGPT requires a public HTTPS tunnel or deployed HTTPS endpoint; use the public URL with `/mcp` and choose no authentication.

The MCP server does not upload, store, or independently read course files. ChatGPT uses only the materials intentionally supplied in the current conversation and calls the server for the Rembox specification and structural audit.
