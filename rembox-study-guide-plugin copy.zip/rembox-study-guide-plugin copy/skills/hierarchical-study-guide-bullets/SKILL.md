---
name: hierarchical-study-guide-bullets
description: Format study-guide definitions and explanations as hierarchical Markdown bullets. Use for Rembox study-guide body content or when the user requests bold term bullets with definitions on indented sub-bullets.
---

# Hierarchical study-guide bullets

Apply this formatting to study-guide topic sections, including definition and explanation lists in reviews and cram sheets. When restyling, preserve every fact, qualification, citation, and source limit. Explicit user formatting requests override this default.

## Formatting rules

- Write section headings as `### Topic Name`, without bullet markers or decorative prefixes.
- Put each main term or concept alone in a bold primary bullet, including its colon: `- **Term:**`.
- Put the definition or explanation on the next line as a sub-bullet indented by two spaces: `  - Explanation.`
- Use additional sub-bullets at the same indentation for multiple facts under one term. Keep source qualifiers with the facts they qualify.
- Never place a definition on the same line as its main term. Avoid paragraph-style definitions; use concise, complete sub-bullets.
- Use standard Markdown hyphens for both bullet levels, not manually typed bullet glyphs such as `•`.
- Leave a blank line after headings and between primary-bullet groups. Keep each primary bullet with its first sub-bullet.

Retain true comparison tables, numbered procedures, requested flashcard/question formats, source notes, and callout purposes. Do not force these structures into term-definition lists. For requested PDF or DOCX output, render the same term-above-explanation hierarchy as native nested lists while retaining Rembox typography, colors, and pagination; do not print literal Markdown syntax.

## Example: Antigen vs. Antibody

This example illustrates formatting only. It is not a factual source for future study guides; use the materials supplied for each request.

```markdown
### Antigen vs. Antibody

- **Antigen:**
  - A marker or foreign target that triggers an immune response.

- **Antibody:**
  - A specific immunoglobulin that binds to an antigen.

- **Key distinction:**
  - The antigen is the target.
  - The antibody recognizes and binds to it.
```

Before delivery, check that every term-definition group has a bold term alone on its primary bullet and all explanations on indented sub-bullets. Confirm plain `###` topic headings and hyphen list markers in Markdown.
