# Rembox layout specification

This is an independent design specification. Apply it directly; no reference document is needed. Keep plugin branding separate from the title of each generated guide.

## Page and typography

- US Letter portrait, 612 x 792 points, white background. Default left and right margins: 51 points, giving a 510-point content width. Top margin: approximately 48 points; bottom: at least 49 points. Adapt for requested paper sizes.
- Arial with its actual Bold face. If unavailable, use a metrically similar sans-serif with a real bold companion and disclose the substitution. Never rely on font size or color alone for bold emphasis.
- Main title: centered, bold, 28 pt, approximately 33 pt line spacing, navy #193D59. Use two lines only when helpful.
- Orange divider: #F27B2C, 2 pt tall, full content width, beneath the title. Subtitle: centered blue #2475A6, 15 pt, about 19 pt line spacing.
- Body: 11 pt Arial, dark slate #253541, about 14 pt line spacing. Bold important terms, numbers, and distinctions selectively. Maintain around 4 pt after each bullet. Use a hanging indent of roughly 12 pt. For term-definition lists, place the bold term on its own primary bullet and each explanation on a separate, more deeply indented sub-bullet; keep the term with its first explanation.
- Subheadings: plain bold 14 pt, around 18 pt line spacing, 8-10 pt before and 5 pt after. Keep with the following content. No marker, checkbox, emoji, bullet, dot, or diamond prefixes on any heading or title. Body lists retain bullets; ordered procedures may use numbers.
- Source notes: 8-9 pt, readable spacing. Do not shrink body text to force a page count.

## Opening page

- Small navy running title and muted source descriptor if supported by current metadata, with a thin pale-blue rule.
- Centered main title, orange rule, blue topic subtitle, and compact left-aligned metadata.
- Full-width pale-teal Source boundary box (#E5F3F1), thin teal border (#248D8B), at least 8 pt horizontal and 6 pt vertical padding.
- Plain blue headings for Learning objectives, How to use this guide, and Coverage map, followed by body bullets.
- A matching Coverage limit box for actual limitations. Allow continuation if necessary; never cram a long orientation onto one page.

## Section styling

Use one muted color family per major topic group, assigned in topic order without attaching any color to a subject. Repeat a family's colors for its subsections. For a short guide, use only the first family. Section banner: full width, bold white 17 pt text, about 21 pt line spacing, 10 pt horizontal and 8 pt vertical padding. A matching pale source-note strip sits below it. Use a matching darker subheading color with adequate contrast.

| Family | Banner | Subheading | Source strip |
| --- | --- | --- | --- |
| Teal | #245B62 | #27727A | #E8F3F3 |
| Blue | #294E7C | #2475A6 | #EAF1F9 |
| Plum | #6C3F69 | #804C7D | #F5EDF5 |
| Green | #395F49 | #48765A | #EDF4EF |
| Ochre | #765124 | #765124 | #F7F1E7 |
| Slate | #4D5666 | #59677B | #EEF1F6 |
| Terracotta | #754239 | #915649 | #F8EEEA |

Use slate for source inventory/differences and terracotta for final rapid review when those sections exist. For additional topic groups, cycle the topic palettes. Meaning must remain clear in grayscale through labels and hierarchy.

## Callouts, tables, and pagination

- Use pale, padded callouts only for meaningful source limits, conflicts, key distinctions, or source-supported warnings. Label their purpose in bold. Reserve pale red for actual source-supported safety warnings; color is not the only signal.
- Tables are for true comparisons. Use bold headers, subtle shaded rows, generous cell padding, wrapped text, and repeated headers across pages. Avoid dense multi-column prose.
- Keep banners with the source strip and first content; avoid stranded headings, clipped callouts, broken bullet glyphs, and overlapping footers. Long sections flow across pages. Use intentional page breaks at major transitions when useful; never impose the sample document's length or topic allocation.
- Footer: thin pale-blue line, muted descriptor on the left, page number on the right; about 7.8-8 pt. Running title/source descriptor must be derived from the current request, not prefilled course metadata.
- Cram sheet uses the same readable body typography, concise topic clusters, strong key-term emphasis, and terracotta banner. Retain critical source qualifications.
- In chat, follow `../../hierarchical-study-guide-bullets/SKILL.md`: `### Topic Name` headings, `- **Term:**` alone on its line, and next-line two-space-indented hyphen sub-bullets for explanations. Retain true comparison tables and numbered procedures; do not claim exact PDF colors or pagination in plain Markdown.
